enum TransactionActor { tenant, owner }
