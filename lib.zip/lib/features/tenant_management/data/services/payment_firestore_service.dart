import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:rentdone/core/trust/tenant_trust_score.dart';
import 'package:rentdone/core/exceptions/security_exceptions.dart';
import 'package:rentdone/core/logging/payment_event_logger.dart';
import '../models/payment_dto.dart';

/// Firestore service for payment/transaction data operations
/// ⚠️ SECURITY: All writes require ownership verification before Firestore rules enforcement
class PaymentFirestoreService {
  final FirebaseFirestore _firestore;
  final FirebaseAuth _auth;

  PaymentFirestoreService({FirebaseFirestore? firestore, FirebaseAuth? auth})
    : _firestore = firestore ?? FirebaseFirestore.instance,
      _auth = auth ?? FirebaseAuth.instance;

  /// Get current authenticated user ID or throw if not authenticated
  String _getCurrentUserIdOrThrow() {
    final uid = _auth.currentUser?.uid;
    if (uid == null || uid.isEmpty) {
      throw UnauthorizedException('User not authenticated');
    }
    return uid;
  }

  /// Verify payment belongs to current user by checking ownerId
  /// SECURITY: Defense-in-depth check before Firestore rules
  Future<String> _verifyPaymentOwnershipOrThrow(String paymentId) async {
    try {
      final currentUserId = _getCurrentUserIdOrThrow();
      final paymentDoc = await _firestore
          .collection('payments')
          .doc(paymentId)
          .get();

      if (!paymentDoc.exists) {
        throw StateError('Payment not found');
      }

      final ownerId = paymentDoc.data()?['ownerId'] as String?;
      if (ownerId != currentUserId) {
        throw UnauthorizedException(
          'User does not own this payment. Cannot modify.',
        );
      }

      return currentUserId;
    } on FirebaseException catch (e) {
      if (e.code == 'permission-denied') {
        throw UnauthorizedException('Permission denied by Firestore rules');
      }
      rethrow;
    }
  }

  /// Record a payment
  Future<void> recordPayment(PaymentDTO paymentDTO) async {
    final logger = PaymentEventLogger.instance;
    try {
      final paymentsRef = _firestore.collection('payments');
      final paymentRef = paymentDTO.id.trim().isEmpty
          ? paymentsRef.doc()
          : paymentsRef.doc(paymentDTO.id);

      final savedPayment = PaymentDTO(
        id: paymentRef.id,
        tenantId: paymentDTO.tenantId,
        ownerId: paymentDTO.ownerId,
        propertyId: paymentDTO.propertyId,
        amount: paymentDTO.amount,
        paymentDate: paymentDTO.paymentDate,
        monthFor: paymentDTO.monthFor,
        paymentMethod: paymentDTO.paymentMethod,
        status: paymentDTO.status,
        createdAt: paymentDTO.createdAt,
        referenceId: paymentDTO.referenceId,
        notes: paymentDTO.notes,
      );

      final tenantRef = _firestore
          .collection('tenants')
          .doc(savedPayment.tenantId);

      await logger.logEvent(
        event: 'PAYMENT_CREATE_ATTEMPT',
        userId: _auth.currentUser?.uid,
        tenantId: paymentDTO.tenantId,
        ownerId: paymentDTO.ownerId,
        paymentId: paymentRef.id,
        idempotencyKey: paymentDTO.referenceId,
        amount: paymentDTO.amount,
        method: paymentDTO.paymentMethod,
        status: 'initiated',
      );

      await _firestore.runTransaction((txn) async {
        final tenantDoc = await txn.get(tenantRef);
        final tenantData = tenantDoc.data() ?? <String, dynamic>{};

        final currentScore = TenantTrustScore.clamp(
          (tenantData['trustScore'] as num?)?.toInt() ??
              TenantTrustScore.defaultScore,
        );

        final dueDay =
            (tenantData['rentDueDate'] as num?)?.toInt() ??
            (tenantData['rentDueDay'] as num?)?.toInt() ??
            1;
        final dueDate = _resolveDueDate(
          monthFor: savedPayment.monthFor,
          dueDay: dueDay,
        );

        final paymentDelta = TenantTrustScore.paymentDelta(
          paymentDate: savedPayment.paymentDate,
          dueDate: dueDate,
          status: savedPayment.status,
        );

        final isOnTime = paymentDelta > 0;
        final nextConsecutiveOnTime = isOnTime
            ? ((tenantData['consecutiveOnTimeMonths'] as num?)?.toInt() ?? 0) +
                  1
            : 0;
        final bonus = TenantTrustScore.consecutiveBonus(
          consecutiveOnTimeMonths: nextConsecutiveOnTime,
          perfectRecord: isOnTime,
        );
        final newScore = TenantTrustScore.clamp(
          currentScore + paymentDelta + bonus,
        );

        final wasLate = !isOnTime;
        final onTimePayments =
            ((tenantData['onTimePayments'] as num?)?.toInt() ?? 0) +
            (isOnTime ? 1 : 0);
        final latePayments =
            ((tenantData['latePayments'] as num?)?.toInt() ?? 0) +
            (wasLate ? 1 : 0);
        final missedPayments =
            ((tenantData['missedPayments'] as num?)?.toInt() ?? 0) +
            (savedPayment.status.trim().toLowerCase() == 'missed' ? 1 : 0);

        txn.set(paymentRef, savedPayment.toMap(), SetOptions(merge: false));

        txn.set(tenantRef, {
          'trustScore': newScore,
          'trustBadge': TenantTrustScore.badgeFor(newScore).label,
          'onTimePayments': onTimePayments,
          'latePayments': latePayments,
          'missedPayments': missedPayments,
          'consecutiveOnTimeMonths': nextConsecutiveOnTime,
          'lastTrustScoreDelta': paymentDelta + bonus,
          'updatedAt': FieldValue.serverTimestamp(),
        }, SetOptions(merge: true));

        final eventRef = tenantRef.collection('trust_score_events').doc();
        txn.set(eventRef, {
          'type': 'payment',
          'paymentId': savedPayment.id,
          'paymentMonth': savedPayment.monthFor,
          'previousScore': currentScore,
          'delta': paymentDelta,
          'bonus': bonus,
          'newScore': newScore,
          'dueDate': Timestamp.fromDate(dueDate),
          'paymentDate': Timestamp.fromDate(savedPayment.paymentDate),
          'createdAt': FieldValue.serverTimestamp(),
          'ownerId': savedPayment.ownerId,
        });
      });

      await logger.logEvent(
        event: 'PAYMENT_SUCCESS',
        userId: _auth.currentUser?.uid,
        tenantId: paymentDTO.tenantId,
        ownerId: paymentDTO.ownerId,
        paymentId: savedPayment.id,
        idempotencyKey: paymentDTO.referenceId,
        amount: paymentDTO.amount,
        method: paymentDTO.paymentMethod,
        status: savedPayment.status,
      );
    } catch (e) {
      await logger.logError(
        event: 'PAYMENT_FAILURE',
        userId: _auth.currentUser?.uid,
        tenantId: paymentDTO.tenantId,
        ownerId: paymentDTO.ownerId,
        paymentId: paymentDTO.id.isEmpty ? null : paymentDTO.id,
        idempotencyKey: paymentDTO.referenceId,
        amount: paymentDTO.amount,
        method: paymentDTO.paymentMethod,
        status: 'failed',
        errorCode: 'record_payment_failed',
        errorMessage: e.toString(),
        error: e,
        stackTrace: StackTrace.current,
      );
      rethrow;
    }
  }

  DateTime _resolveDueDate({required String monthFor, required int dueDay}) {
    final now = DateTime.now();
    final monthToken = monthFor.trim();
    final monthPattern = RegExp(
      r'^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+(\d{4})$',
      caseSensitive: false,
    );
    final match = monthPattern.firstMatch(monthToken);

    int year = now.year;
    int month = now.month;

    if (match != null) {
      final monthLabel = match.group(1)!.toLowerCase();
      final parsedYear = int.tryParse(match.group(2)!);
      final monthMap = <String, int>{
        'jan': 1,
        'feb': 2,
        'mar': 3,
        'apr': 4,
        'may': 5,
        'jun': 6,
        'jul': 7,
        'aug': 8,
        'sep': 9,
        'oct': 10,
        'nov': 11,
        'dec': 12,
      };

      year = parsedYear ?? now.year;
      month = monthMap[monthLabel] ?? now.month;
    }

    final safeDueDay = dueDay.clamp(1, 31).toInt();
    final lastDay = DateTime(year, month + 1, 0).day;
    final cappedDueDay = safeDueDay > lastDay ? lastDay : safeDueDay;

    return DateTime(year, month, cappedDueDay);
  }

  /// Get payment history for tenant (paginated)
  Future<List<PaymentDTO>> getPaymentHistory(
    String tenantId, {
    required int limit,
    required int page,
  }) async {
    try {
      final offset = (page - 1) * limit;
      List<QueryDocumentSnapshot<Map<String, dynamic>>> docs;
      try {
        final result = await _firestore
            .collection('payments')
            .where('tenantId', isEqualTo: tenantId)
            .orderBy('createdAt', descending: true)
            .limit(limit + offset)
            .get();
        docs = result.docs;
      } on FirebaseException catch (error) {
        if (error.code != 'failed-precondition') rethrow;

        // Fallback while composite index is provisioning.
        final fallback = await _firestore
            .collection('payments')
            .where('tenantId', isEqualTo: tenantId)
            .limit((limit + offset) * 8)
            .get();

        final sorted = [...fallback.docs]
          ..sort((a, b) {
            final aCreated = (a.data()['createdAt'] as Timestamp?)?.toDate();
            final bCreated = (b.data()['createdAt'] as Timestamp?)?.toDate();

            if (aCreated == null && bCreated == null) {
              return b.id.compareTo(a.id);
            }
            if (aCreated == null) return 1;
            if (bCreated == null) return -1;

            final byDate = bCreated.compareTo(aCreated);
            if (byDate != 0) return byDate;
            return b.id.compareTo(a.id);
          });

        docs = sorted.take(limit + offset).toList();
      }

      final paginatedDocs = docs.skip(offset).take(limit).toList();
      return paginatedDocs
          .map((doc) => PaymentDTO.fromMap(doc.data()))
          .toList();
    } catch (e) {
      rethrow;
    }
  }

  /// Get all pending payments for owner
  Future<List<PaymentDTO>> getPendingPayments(String ownerId) async {
    try {
      final docs = await _firestore
          .collection('payments')
          .where('ownerId', isEqualTo: ownerId)
          .where('status', whereIn: ['pending', 'partial'])
          .orderBy('createdAt', descending: true)
          .get();

      return docs.docs.map((doc) => PaymentDTO.fromMap(doc.data())).toList();
    } catch (e) {
      rethrow;
    }
  }

  /// Get payments by month
  Future<List<PaymentDTO>> getPaymentsByMonth(
    String ownerId,
    String monthFor,
  ) async {
    try {
      final docs = await _firestore
          .collection('payments')
          .where('ownerId', isEqualTo: ownerId)
          .where('monthFor', isEqualTo: monthFor)
          .get();

      return docs.docs.map((doc) => PaymentDTO.fromMap(doc.data())).toList();
    } catch (e) {
      rethrow;
    }
  }

  /// Update payment status with ownership verification and state machine validation
  /// SECURITY: Verifies ownership and validates status transitions
  Future<void> updatePaymentStatus(String paymentId, String status) async {
    try {
      // SECURITY: Verify ownership BEFORE write
      await _verifyPaymentOwnershipOrThrow(paymentId);

      // Validate status is one of allowed values
      final normalizedStatus = status.trim().toLowerCase();
      if (!['paid', 'partial', 'unpaid'].contains(normalizedStatus)) {
        throw ArgumentError(
          'Invalid status "$status". Allowed: paid, partial, unpaid',
        );
      }

      // Update with ownership already verified above
      await _firestore.collection('payments').doc(paymentId).update({
        'status': normalizedStatus,
        'updatedAt': FieldValue.serverTimestamp(),
      });
    } on FirebaseException catch (e) {
      if (e.code == 'permission-denied') {
        throw UnauthorizedException('Firestore permission denied');
      }
      rethrow;
    }
  }

  /// Get monthly revenue for owner
  Future<int> getMonthlyRevenue(String ownerId) async {
    try {
      final currentMonth = _getCurrentMonthString();
      final docs = await _firestore
          .collection('payments')
          .where('ownerId', isEqualTo: ownerId)
          .where('monthFor', isEqualTo: currentMonth)
          .where('status', isEqualTo: 'paid')
          .get();

      int total = 0;
      for (final doc in docs.docs) {
        final payment = PaymentDTO.fromMap(doc.data());
        total += payment.amount;
      }

      return total;
    } catch (e) {
      rethrow;
    }
  }

  /// Get pending amount due
  Future<int> getPendingAmount(String ownerId) async {
    try {
      final docs = await _firestore
          .collection('payments')
          .where('ownerId', isEqualTo: ownerId)
          .where('status', whereIn: ['pending', 'partial'])
          .get();

      int total = 0;
      for (final doc in docs.docs) {
        final payment = PaymentDTO.fromMap(doc.data());
        total += payment.amount;
      }

      return total;
    } catch (e) {
      rethrow;
    }
  }

  /// Get overdue amount
  Future<int> getOverdueAmount(String ownerId) async {
    try {
      final now = DateTime.now();
      final docs = await _firestore
          .collection('payments')
          .where('ownerId', isEqualTo: ownerId)
          .where('status', whereIn: ['pending', 'partial'])
          .get();

      int total = 0;
      for (final doc in docs.docs) {
        final payment = PaymentDTO.fromMap(doc.data());
        // If payment date is before today, it's overdue
        if (payment.paymentDate.isBefore(now)) {
          total += payment.amount;
        }
      }

      return total;
    } catch (e) {
      rethrow;
    }
  }

  /// Helper: Get current month string
  String _getCurrentMonthString() {
    final now = DateTime.now();
    const months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    return '${months[now.month - 1]} ${now.year}';
  }
}
